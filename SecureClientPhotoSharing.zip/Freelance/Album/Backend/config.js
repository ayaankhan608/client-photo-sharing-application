export default {
    mongoURI: 'mongodb+srv://harshalhonde17:harshal%40123@cluster0.b0mwyen.mongodb.net/Blogs?retryWrites=true&w=majority',
    jwtSecret: '65985965!@*&441564',
  };